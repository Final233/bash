#!/usr/bin/env bash
#
#********************************************************************
#Author:                Final
#QQ:                    438803792
#Date:                  2020-05-23
#FileName：             /etc/profile.d/danger.sh
#URL:                   http://cnblogs.com/fina
#Description：          The test script
#Copyright (C):         2020 All rights reserved
#********************************************************************
#将此文件放入到/etc/profile.d/目录下，环境可根据实际情况来写
echo -e "\033[1;5;31m您现在在虚拟机环境操作!\033[0m"

